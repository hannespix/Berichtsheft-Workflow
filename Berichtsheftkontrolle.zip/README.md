# Berichtsheftkontrolle
## Ausbildungsberater Gärtner – RP Freiburg

---

### Schnellstart (2 Schritte)

1. **Diesen Ordner** komplett in einen gemeinsamen Netzwerkordner kopieren
2. **`berichtsheftkontrolle.html`** in Chrome oder Edge öffnen

Die Datenbank wird **automatisch** erkannt und geladen – kein Dialog nötig!
Beim ersten Speichern fragt der Browser einmalig nach Ordner-Zugriff (🔓-Button in der Leiste). Danach läuft Auto-Save im Hintergrund.

---

### Ordnerstruktur

```
Berichtsheftkontrolle/
├── berichtsheftkontrolle.html      ← Das Tool (im Browser öffnen)
├── berichtsheftkontrolle.sqlite    ← Datenbank (vorinstalliert)
├── backups/                        ← Automatische Sicherungen
├── .gitignore                      ← Für GitHub (ignoriert .sqlite)
└── README.md                       ← Diese Datei
```

### Was ist bereits vorinstalliert?

Die Datenbank enthält:
- **7 Fachrichtungen**: Baumschule, Friedhofsgärtnerei, GaLaBau, Gemüsebau, Obstbau, Staudengärtnerei, Zierpflanzenbau
- **5 Abschlussjahrgänge**: S2027 (aktiv), S2028, S2029, W2026, W2027
- **2 Prüfer**: Hannes Pix, Christoph Zilz
- **Einstellungen**: E-Mail Freisprechung, RP-Adressen

### Nächste Schritte nach dem ersten Start

1. Unter **Schüler-Import**: CSV aus IBYKUS hochladen (Schulen, Klassen, Jahrgänge werden automatisch angelegt!)
2. Unter **Kontrollplanung**: Termine anlegen
3. Los kontrollieren!

> **Tipp**: Der Import erkennt automatisch Berufsschulen, Fachrichtungen, Lehrjahre und Abschlussjahrgänge aus den IBYKUS-Daten. Kein manuelles Anlegen nötig.

### Systemanforderungen

- **Browser**: Chrome 86+ oder Edge 86+ (andere Browser nicht unterstützt)
- **Netzwerk**: Internetzugang beim ersten Laden (danach gecacht)
- **Installation**: Keine nötig – läuft auf Zero-Trust-Rechnern ohne Adminrechte

### Parallele Bearbeitung (2–3 Personen)

- Jeder öffnet die HTML-Datei in seinem Browser → "Starten" → selben Ordner wählen
- **Auto-Save**: Jede Änderung wird automatisch nach 2 Sekunden gespeichert
- **Backup-History**: Alle 5 Minuten wird ein Backup in `backups/` erstellt (letzte 20 behalten)
- Bei Konflikten (anderer User hat gleichzeitig gespeichert): Warnung erscheint

### Tastaturkürzel (KW-Raster)

| Taste       | Aktion                                    |
|-------------|-------------------------------------------|
| ← → ↑ ↓    | Navigation zwischen KW-Zellen             |
| A–G, I      | Mängel-Code ein/aus toggeln               |
| H           | Fehltage-Eingabe öffnen (0–5)             |
| 1–5         | Sofort: Fehltage setzen                   |
| 0           | Fehltage entfernen                        |
| Entf        | Alle Codes der Zelle löschen              |
| Leertaste   | Vollständiges Bearbeitungsfenster öffnen  |
| Tab         | Zur nächsten Zelle                        |

### Mängel-Codes

| Code | Bedeutung                        |
|------|----------------------------------|
| A    | Unterschrift Azubi fehlt         |
| B    | Unterschrift Ausbilder fehlt     |
| C    | Kurs-/Berufsschulthemen fehlen   |
| D    | Wetter fehlt                     |
| E    | Inhaltlich lückenhaft            |
| F    | (Fast) komplette Berichte fehlen |
| G    | Datum/Kalenderwoche fehlt        |
| H    | Fehltage (Anzahl)                |
| I    | Sonstiges                        |

### Datensicherung

- **Auto-Save**: Jede Änderung wird automatisch 2 Sekunden nach der letzten Eingabe gespeichert
- **Auto-Backup**: Alle 5 Minuten wird eine Sicherungskopie in `backups/` erstellt
- Die letzten 20 Backups werden automatisch behalten, ältere gelöscht
- Manuelles Backup: Im Tool den Button "💾 Manuell speichern + Backup" nutzen

---

Regierungspräsidium Freiburg · Abteilung 3 / Referat 31
